package com.capgemini.geecon2011.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "GC_ORDER")
public class Order {
	@Id
	@GeneratedValue
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY) // defaults to EAGER!!
    @JoinColumn(nullable = false)
	private Customer customer;
	
	@Column(nullable = false)
	private String referenceNo;
	
	@OneToMany(mappedBy = "order")
	private Set<OrderPosition> positions = new HashSet<OrderPosition>();

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public Long getId() {
		return id;
	}
	
	public Set<OrderPosition> getPositions() {
		return positions;
	}
	
	public void addPosition(OrderPosition position) {
		position.setOrder(this);
		positions.add(position);
	}
}
