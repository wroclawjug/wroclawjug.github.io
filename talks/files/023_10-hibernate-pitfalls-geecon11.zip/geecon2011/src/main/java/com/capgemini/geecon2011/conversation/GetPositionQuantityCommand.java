package com.capgemini.geecon2011.conversation;

import org.hibernate.Query;
import org.hibernate.Session;

import com.capgemini.geecon2011.PersistenceCommand;

public class GetPositionQuantityCommand implements
		PersistenceCommand {
	private final String QUERY = "select quantity from OrderPosition where id = :id";
	private Long positionId;
	private int quantity;

	public GetPositionQuantityCommand(Long positionId) {
		super();
		this.positionId = positionId;
	}

	public void execute(Session session) {
		Query query = session.createQuery(QUERY);
		query.setLong("id", positionId);

		quantity = (Integer) query.uniqueResult();
	}

	public int getQuantity() {
		return quantity;
	}
}