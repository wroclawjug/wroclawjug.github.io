package com.capgemini.geecon2011;

import org.hibernate.Session;

public interface PersistenceCommand {
	void execute(Session session);
}
