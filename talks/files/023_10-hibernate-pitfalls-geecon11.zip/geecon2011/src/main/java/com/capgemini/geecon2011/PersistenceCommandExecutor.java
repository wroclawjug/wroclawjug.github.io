package com.capgemini.geecon2011;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PersistenceCommandExecutor {
	private static Logger log = LoggerFactory
			.getLogger(PersistenceCommandExecutor.class);
	private final SessionFactory sessionFactory;
	private List<PersistenceCommand> commandChain;

	public PersistenceCommandExecutor(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		commandChain = new ArrayList<PersistenceCommand>();
	}

	public void addCommand(PersistenceCommand command) {
		commandChain.add(command);
	}

	public void addCommands(List<PersistenceCommand> commands) {
		commandChain.addAll(commands);
	}

	public void executeCommands() {
		executeCommands(sessionFactory, commandChain);
	}

	public static void executeCommand(SessionFactory sessionFactory,
			PersistenceCommand command) {
		executeCommands(sessionFactory, Collections.singletonList(command));
	}

	private static void executeCommands(SessionFactory sessionFactory,
			List<PersistenceCommand> commands) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			for (PersistenceCommand command : commands) {
				command.execute(session);
			}
			transaction.commit();
		} catch (RuntimeException e) {
			try {
				transaction.rollback();
			} catch (RuntimeException t) {
				log.error("Couldn't roll back transaction", t);
			}
			throw e;
		} finally {
			session.close();
		}
	}
}
