package com.capgemini.geecon2011.conversation;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.capgemini.geecon2011.model.Order;
import com.capgemini.geecon2011.model.OrderPosition;

public class SomeOrderConversation {
	public static final int NEW_POSITION_QUANTITY = 25;

	private final Long orderId;

	private final Session session;

	private Order order;

	public SomeOrderConversation(Long orderId, SessionFactory sessionFactory) {
		this(orderId, sessionFactory, true);
	}

	public SomeOrderConversation(Long orderId, SessionFactory sessionFactory,
			boolean manualFlushing) {
		this.orderId = orderId;
		this.session = sessionFactory.openSession();
		if (manualFlushing)
			this.session.setFlushMode(FlushMode.MANUAL);
	}

	public void loadOrder() {
		session.beginTransaction();
		order = (Order) session.load(Order.class, orderId);
		session.getTransaction().commit();
	}

	public void updatePosition() {
		session.beginTransaction();
		if (!order.getPositions().isEmpty()) {
			OrderPosition orderPosition = order.getPositions().iterator()
					.next();
			orderPosition.setQuantity(NEW_POSITION_QUANTITY);
			session.save(orderPosition);
		}

		session.getTransaction().commit();
	}

	public int getPositionQuantityBypassingCache(Long positionId) {
		session.beginTransaction();
		GetPositionQuantityCommand command = new GetPositionQuantityCommand(positionId);
		command.execute(session);
		session.getTransaction().commit();

		return command.getQuantity();
	}

	public int getPositionQuantityFromCache(Long positionId) {
		session.beginTransaction();
		OrderPosition position = (OrderPosition) session
				.createCriteria(OrderPosition.class)
				.add(Restrictions.eq("id", positionId)).uniqueResult();
		final int qty = position.getQuantity();
		session.getTransaction().commit();
		return qty;
	}

	public void applyChanges() {
		session.beginTransaction();
		session.flush();
		session.getTransaction().commit();
		session.close();
	}

	public void cancel() {
		session.close();
	}
}