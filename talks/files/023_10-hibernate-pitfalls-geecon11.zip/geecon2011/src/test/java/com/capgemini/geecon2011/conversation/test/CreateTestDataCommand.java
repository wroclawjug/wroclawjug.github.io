package com.capgemini.geecon2011.conversation.test;

import org.hibernate.Session;

import com.capgemini.geecon2011.PersistenceCommand;
import com.capgemini.geecon2011.model.Customer;
import com.capgemini.geecon2011.model.Order;
import com.capgemini.geecon2011.model.OrderPosition;

public class CreateTestDataCommand implements PersistenceCommand {
	private Long orderId;

	private Long positionId;

	public void execute(Session session) {
		Customer customer = new Customer();
		customer.setName("Marek Matczak");
		session.save(customer);

		Order order = new Order();
		order.setReferenceNo("ABC-12345");
		order.setCustomer(customer);
		orderId = (Long) session.save(order);

		OrderPosition position = new OrderPosition();
		position.setDescription("T-Shirts");
		position.setQuantity(20);
		order.addPosition(position);
		positionId = (Long) session.save(position);
	}

	public Long getOrderId() {
		return orderId;
	}

	public Long getPositionId() {
		return positionId;
	}
}