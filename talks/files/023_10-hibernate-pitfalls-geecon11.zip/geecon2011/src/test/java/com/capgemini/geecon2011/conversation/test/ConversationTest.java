package com.capgemini.geecon2011.conversation.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.geecon2011.PersistenceCommandExecutor;
import com.capgemini.geecon2011.conversation.GetPositionQuantityCommand;
import com.capgemini.geecon2011.conversation.SomeOrderConversation;
import com.capgemini.geecon2011.model.Customer;
import com.capgemini.geecon2011.model.Order;
import com.capgemini.geecon2011.model.OrderPosition;

public class ConversationTest {
	private SessionFactory sessionFactory;

	@Before
	public void setUpSessionFactory() {
		sessionFactory = new Configuration().addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Order.class)
				.addAnnotatedClass(OrderPosition.class).buildSessionFactory();
	}

	@Test
	public void conversationCommit() {
		CreateTestDataCommand testDataCommand = new CreateTestDataCommand();
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				testDataCommand);

		SomeOrderConversation conversation = new SomeOrderConversation(
				testDataCommand.getOrderId(), sessionFactory);
		// 1st step: just load the order
		conversation.loadOrder();

		// check position's quantity BEFORE update
		GetPositionQuantityCommand quantityCommand = new GetPositionQuantityCommand(
				testDataCommand.getPositionId());
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyBeforeUpdate = quantityCommand.getQuantity();

		// 2nd step: update position's quantity
		conversation.updatePosition();

		// check position's quantity AFTER update
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterUpdate = quantityCommand.getQuantity();

		// changes should NOT be populated (flushed)
		assertEquals(qtyBeforeUpdate, qtyAfterUpdate);

		// 3rd step: commit changes made to the position
		conversation.applyChanges();

		// check if the new quantity has been populated
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterCommit = quantityCommand.getQuantity();
		assertEquals(SomeOrderConversation.NEW_POSITION_QUANTITY,
				qtyAfterCommit);
	}

	@Test
	public void conversationRollback() {
		CreateTestDataCommand testDataCommand = new CreateTestDataCommand();
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				testDataCommand);

		SomeOrderConversation conversation = new SomeOrderConversation(
				testDataCommand.getOrderId(), sessionFactory);
		// 1st step: just load the order
		conversation.loadOrder();

		// check position's quantity BEFORE update
		GetPositionQuantityCommand quantityCommand = new GetPositionQuantityCommand(
				testDataCommand.getPositionId());
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyBeforeUpdate = quantityCommand.getQuantity();

		// 2nd step: update position's quantity
		conversation.updatePosition();

		// check position's quantity AFTER update
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterUpdate = quantityCommand.getQuantity();

		// changes should NOT be populated (flushed)
		assertEquals(qtyBeforeUpdate, qtyAfterUpdate);

		// 3rd step: discard changes made to the position
		conversation.cancel();

		// check if the new quantity has NOT been populated
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterCommit = quantityCommand.getQuantity();
		assertEquals(qtyAfterUpdate, qtyAfterCommit);
	}

	@Test
	public void conversationAutoVsManualFlush() {
		CreateTestDataCommand testDataCommand = new CreateTestDataCommand();
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				testDataCommand);

		// don't use manual flushing
		SomeOrderConversation conversation = new SomeOrderConversation(
				testDataCommand.getOrderId(), sessionFactory, false);
		// 1st step: just load the order
		conversation.loadOrder();

		// check position's quantity BEFORE update
		GetPositionQuantityCommand quantityCommand = new GetPositionQuantityCommand(
				testDataCommand.getPositionId());
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyBeforeUpdate = quantityCommand.getQuantity();

		// 2nd step: update position's quantity
		conversation.updatePosition();

		// check position's quantity AFTER update
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterUpdate = quantityCommand.getQuantity();

		// changes ARE populated thanks to auto flushing at the transaction end
		assertFalse(qtyBeforeUpdate == qtyAfterUpdate);
		assertEquals(SomeOrderConversation.NEW_POSITION_QUANTITY,
				qtyAfterUpdate);

		// 3rd step: try to discard changes made to the position
		conversation.cancel();

		// the new quantity was not discarded
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterCommit = quantityCommand.getQuantity();
		assertEquals(SomeOrderConversation.NEW_POSITION_QUANTITY,
				qtyAfterCommit);
	}

	@Test
	public void conversationStaleData() {
		CreateTestDataCommand testDataCommand = new CreateTestDataCommand();
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				testDataCommand);

		SomeOrderConversation conversation = new SomeOrderConversation(
				testDataCommand.getOrderId(), sessionFactory);
		// 1st step: just load the order
		conversation.loadOrder();

		// check position's quantity BEFORE update
		GetPositionQuantityCommand quantityCommand = new GetPositionQuantityCommand(
				testDataCommand.getPositionId());
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyBeforeUpdate = quantityCommand.getQuantity();

		// 2nd step: update position's quantity
		conversation.updatePosition();

		// check position's quantity AFTER update
		PersistenceCommandExecutor.executeCommand(sessionFactory,
				quantityCommand);
		final int qtyAfterUpdate = quantityCommand.getQuantity();
		// changes should NOT be populated (flushed)
		assertEquals(qtyBeforeUpdate, qtyAfterUpdate);

		// querying where 1st Level Cache is involved
		final int qtyFromCache = conversation
				.getPositionQuantityFromCache(testDataCommand.getPositionId());
		assertEquals(SomeOrderConversation.NEW_POSITION_QUANTITY, qtyFromCache);

		// querying where 1st Level Cache is bypassed
		final int qtyBypassingCache = conversation
				.getPositionQuantityBypassingCache(testDataCommand
						.getPositionId());
		assertEquals(qtyBeforeUpdate, qtyBypassingCache);

		// 3rd step: try to discard changes made to the position
		conversation.cancel();
	}
}
