package org.jug.jsf2.beans;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.ComponentSystemEvent;

@ManagedBean
@SessionScoped
public class AjaxServiceBean {

	private String name = "";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMD5() throws NoSuchAlgorithmException {
		// found in google:
		MessageDigest m = MessageDigest.getInstance("MD5");
		m.reset();
		m.update(name.getBytes());
		byte[] digest = m.digest();
		BigInteger bigInt = new BigInteger(1, digest);
		String hashtext = bigInt.toString(16);

		while (hashtext.length() < 32) {
			hashtext = "0" + hashtext;
		}

		return hashtext;
	}

	public String getMemory() {

		long mem = Runtime.getRuntime().freeMemory();
		return String.valueOf(mem);
	}

	public void update(AjaxBehaviorEvent e) {

		System.out.println(e);
	}

	public void phaseListener(ComponentSystemEvent e) {

		System.out.println(e);
	}

	@ManagedProperty(value = "very import... text 2x")
	private String text;

	public String getText() {

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	private Boolean isOpen;

	public void setIsOpen(Boolean isOpen) {
		this.isOpen = isOpen;
	}

	public Boolean getIsOpen() {
		return isOpen;
	}

}
